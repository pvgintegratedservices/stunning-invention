# PVG Free Website
Upload `index.html` and the `assets` folder to a public GitHub repository, then enable GitHub Pages from Settings → Pages → Deploy from a branch → main → root.
